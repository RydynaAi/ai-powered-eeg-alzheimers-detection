ملفات بيانات EEG الخام (.set) تم حذفها من هذا الأرشيف لتقليل الحجم.
ارفعيها بشكل منفصل على Google Drive أو Kaggle وضيفي رابطها هنا، أو استخدمي Git LFS لتتبعها.

الملفات الأصلية:
- sub-056_task-eyesclosed_eeg.set (~33MB)
- sub-057_task-eyesclosed_eeg.set (~31MB)
- sub-016_task-eyesclosed_eeg.set (~40MB)
